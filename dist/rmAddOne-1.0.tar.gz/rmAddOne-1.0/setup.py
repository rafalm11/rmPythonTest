from distutils.core import setup
setup(name="rmAddOne",
      version="1.0",
      py_modules=["addOne"])